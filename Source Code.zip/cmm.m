close all
clear all 
clc
tic
% A=rand(6,7); B=rand(7,5);D=rand(6,5); C=rand(5,6); E=rand(5,6);
% M1=A;M2=B;M3=C;M4=D;M5=E;
% [rA cA]=size(A);
% [rB cB]=size(B);
% [rC cC]=size(C);
% [rD cD]=size(D);
% [rE cE]=size(E);
input_file1 = regexp(fileread('ZDT21.txt'), '\r?\n', 'split');% 
input_file=load ('ZDT2.txt');

%varargin=input_file
itr=(input_file)%[[rA cA];[rB cB];[rC cC];[rD cD];[rE cE]]
[in jn]= size(itr)

%% setting up possible Metrix multiplication sequence
I2=1;
for I1=1:in
    for I=1:in
if (itr(I1,2)==itr(I,1))
    (' match')
    break
else
    (' no match')
    if I==in
temp=itr(I1,:);
itr(I1,:)=itr(I,:);
itr(I,:)=temp;
temp1=input_file1(1,I1);
input_file1(1,I1)=input_file1(1,I);
input_file1(1,I)=temp1;
itr;
end
end
    end
end
%%
for I1=1:in
    for I=1:in
if (itr(I1,1)==itr(I,2))
    (' match')
    break
else
    (' no match')
    if I==in
temp=itr(I1,:);
itr(I1,:)=itr(1,:);
itr(1,:)=temp;
temp1=input_file1(1,I1);
input_file1(1,I1)=input_file1(1,1);
input_file1(1,1)=temp1;
itr;
end
end
    end
end

%%
for I2=1:in
    if I2+1>length(itr)
        ('no multi')
    elseif itr(I2,2)== itr (I2+1,1)
        (' pr ok')
    else
        ('error')
         for n=I2:in
             if n+1>length(itr)
                 ('no no')
             else
             m=I2;
             all=n+1;
             if itr(m,2)== itr (all,1)
         'mil gya'
         temp=itr(I2+1,:);
itr(I2+1,:)=itr(all,:);
itr(all,:)=temp;

break
             end
             end
         end
   
    end
end
    
itr2=itr;
inputfile2=input_file1;
%%
minrang=itr2(:,1);
maxrang=itr2(:,2);
for ni=1:length(itr2)
    M(ni).matrix=rand(minrang(ni,1),maxrang(ni,1));
end
%%
%sequential multiplications
sum=0
[row col]=size(itr2);
for p=1:row-1
    sum=sum+(itr2(1,1)*itr2(p+1,1)*itr2(p+1,2));
end
seq_mult=sum
%%
main(M(1:ni).matrix)

lt load('opt_multi.txt') regexp(fileread('final_exp.txt'), '\r?\n', 'split') timeElapsed] )

writetable(T,'outs.xls')








