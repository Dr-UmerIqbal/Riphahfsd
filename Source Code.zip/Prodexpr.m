function expr = Prodexpr(i,j,s,vnames)
if i==j
    expr = vnames{i};
else
    k = s(j,i);
    expr = ['(' Prodexpr(i,k-1,s,vnames) '*' Prodexpr(k,j,s,vnames) ')'];
fid=fopen('final_exp.txt','w');
fprintf(fid, [ expr ]);
fclose(fid);true
end

end % Prodexpr